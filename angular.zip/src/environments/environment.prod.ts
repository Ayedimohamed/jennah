export const environment = {
  production: true,
  Sk: 'b786df951ba318993624ccbc7bd46c51bb4c666472bab3c291ad1880edde950a',

  /* test */

  /*API_URL: 'https://sportbook-server.demo-kusa.com/',
  ROOT_URL: 'https://sportbook-admin.demo-kusa.com/',
  JSON_SERVER_URL: 'https://sportbook-json.demo-kusa.com/',*/

  /* prod */

  API_URL: 'https://api1.twin.tn/',
  ROOT_URL: 'https://ad.twin.tn/',
  JSON_SERVER_URL: 'https://json.twin.tn/',
};
