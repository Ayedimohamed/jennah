import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeBlogComponent } from './components/home-page/home-blog/home-blog.component';
import { HomeComponent } from './pages/home/home.component';
import { SharedModule } from '../shared/shared.module';
import { FeaturedProductsComponent } from './components/home-page/featured-products/featured-products.component';
import { BannerComponent } from './components/banner/banner.component';
import { AppRoutingModule } from '../app-routing.module';
import { ShoppingComponent } from './pages/shopping/shopping.component';
import { FilterComponent } from './components/shopping-page/filter/filter.component';
import { HeaderComponent } from './components/shopping-page/header/header.component';
import { PromotionComponent } from './pages/promotion/promotion.component';
import { SliderPromoComponent } from './components/promotion-page/slider-promo/slider-promo.component';
import { BannerPromoComponent } from './components/promotion-page/banner-promo/banner-promo.component';
import { ServicesComponent } from './components/services/services.component';
import { BlogComponent } from './pages/blog/blog.component';
import { BlogSummaryComponent } from './components/blog-page/blog-summary/blog-summary.component';
import { BlogHeaderComponent } from './components/blog-page/blog-header/blog-header.component';
import { BlogSidebarComponent } from './components/blog-page/blog-sidebar/blog-sidebar.component';
import { BlogDetailsComponent } from './pages/blog-details/blog-details.component';
import { CommentsComponent } from './components/blog-page/comments/comments.component';
import { BlogInfosComponent } from './components/blog-page/blog-infos/blog-infos.component';
import { BlogDetailsSummaryComponent } from './components/blog-page/blog-details-summary/blog-details-summary.component';
import { SliderComponent } from './components/home-page/slider/slider.component';
import { BrandsComponent } from './components/home-page/brands/brands.component';
import { ProductSummaryPromoComponent } from './components/promotion-page/product-summary-promo/product-summary-promo.component';
import { ProductSummarySmPromoComponent } from './components/promotion-page/product-summary-sm-promo/product-summary-sm-promo.component';
import { ProductSummaryShoppingComponent } from './components/shopping-page/product-summary-shopping/product-summary-shopping.component';
import { NewArrivalsComponent } from './components/home-page/new-arrivals/new-arrivals.component';
import { ProductSummaryComponent } from './components/home-page/product-summary/product-summary.component';
import { ProductSummarySmComponent } from './components/home-page/product-summary-sm/product-summary-sm.component';
import { QuickViewComponent } from './components/quick-view/quick-view.component';
import { ProductDetailComponent } from './components/product-details-page/product-detail/product-detail.component';
import { SidebarComponent } from './components/product-details-page/sidebar/sidebar.component';
import { ProductInfoComponent } from './components/product-details-page/product-info/product-info.component';
import { AboutUsComponent } from './pages/about-us/about-us.component';


const SharedModules = [
  SharedModule,
  AppRoutingModule
];

const HomeCoponents = [
  HomeComponent,
  BrandsComponent,
  FeaturedProductsComponent,
  HomeBlogComponent,
  NewArrivalsComponent,
  ProductSummaryComponent,
  ProductSummarySmComponent,
  SliderComponent
];

const BlogCoponents = [
  BlogComponent, 
  BlogSummaryComponent, 
  BlogHeaderComponent, 
  BlogSidebarComponent, 
  BlogDetailsComponent, 
  BlogInfosComponent, 
  BlogDetailsSummaryComponent
];

const ProductCoponents = [
  PromotionComponent,
  SliderPromoComponent,
  BannerPromoComponent,
  ProductSummaryPromoComponent, 
  ProductSummarySmPromoComponent, 
  ProductSummaryShoppingComponent,
  FilterComponent,
  ProductInfoComponent,
  ShoppingComponent,
  ProductDetailComponent,
  QuickViewComponent,
  SidebarComponent,
  CommentsComponent
];

const SharedComponents = [
  BannerComponent,
  HeaderComponent,
  ServicesComponent, 
  AboutUsComponent
];

@NgModule({
  declarations: [SharedComponents, ProductCoponents, BlogCoponents, HomeCoponents],
  imports: [
    CommonModule,
    SharedModules
  ],
  exports: [
    SharedModules,
    SharedComponents, 
    ProductCoponents, 
    BlogCoponents, 
    HomeCoponents
  ]
})
export class PublicModule { }
