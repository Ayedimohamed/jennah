import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductSummaryPromoComponent } from './product-summary-promo.component';

describe('ProductSummaryPromoComponent', () => {
  let component: ProductSummaryPromoComponent;
  let fixture: ComponentFixture<ProductSummaryPromoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductSummaryPromoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductSummaryPromoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
