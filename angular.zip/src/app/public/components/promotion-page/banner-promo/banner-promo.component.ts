import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-banner-promo',
  templateUrl: './banner-promo.component.html',
  styleUrls: ['./banner-promo.component.scss']
})
export class BannerPromoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
