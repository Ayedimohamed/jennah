import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductSummarySmPromoComponent } from './product-summary-sm-promo.component';

describe('ProductSummarySmPromoComponent', () => {
  let component: ProductSummarySmPromoComponent;
  let fixture: ComponentFixture<ProductSummarySmPromoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductSummarySmPromoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductSummarySmPromoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
