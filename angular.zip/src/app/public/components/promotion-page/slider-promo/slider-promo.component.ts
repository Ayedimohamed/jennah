import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slider-promo',
  templateUrl: './slider-promo.component.html',
  styleUrls: ['./slider-promo.component.scss']
})
export class SliderPromoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
