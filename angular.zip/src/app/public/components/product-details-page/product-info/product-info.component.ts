import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ShopService } from 'src/app/shared/services/shop.service';
import { environment } from 'src/environments/environment';


const API_URL = environment.API_URL;

@Component({
  selector: 'app-product-info',
  templateUrl: './product-info.component.html',
  styleUrls: ['./product-info.component.scss']
})
export class ProductInfoComponent implements OnInit {
  
  public baseurl = API_URL;
  public infos : any;
  public id : any;
  public placement : any;



  public success: any;
  public error = null;

  public fileStat : boolean;

  public comments = [] ;

  constructor(    
    private ExternalRequest: ShopService,
    private activatedroute: ActivatedRoute,
  ) { }

  ngOnInit(): void {
    this.getInformations();
  }

  
  getInformations(): void {

    this.id = this.activatedroute.snapshot.paramMap.get('id');

    this.ExternalRequest.get(this.id).subscribe(
     (data) => {
       this.infos = data;
       console.log('data******',this.infos);
     },
     (err) => {
       this.error = err;
     }
   );
  }
  
  sendInformations(): void {

    this.id = this.activatedroute.snapshot.paramMap.get('id');

    this.ExternalRequest.get(this.id).subscribe(
     (data) => {
       this.infos = data;
       console.log('data******',this.infos);
     },
     (err) => {
       this.error = err;
     }
   );
  }
}
