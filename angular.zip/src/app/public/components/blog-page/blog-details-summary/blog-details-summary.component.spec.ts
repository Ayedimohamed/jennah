import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BlogDetailsSummaryComponent } from './blog-details-summary.component';

describe('BlogDetailsSummaryComponent', () => {
  let component: BlogDetailsSummaryComponent;
  let fixture: ComponentFixture<BlogDetailsSummaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BlogDetailsSummaryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BlogDetailsSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
