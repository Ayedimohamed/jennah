import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-details-summary',
  templateUrl: './blog-details-summary.component.html',
  styleUrls: ['./blog-details-summary.component.scss']
})
export class BlogDetailsSummaryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
