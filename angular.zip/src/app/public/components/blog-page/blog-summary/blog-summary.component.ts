import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-summary',
  templateUrl: './blog-summary.component.html',
  styleUrls: ['./blog-summary.component.scss']
})
export class BlogSummaryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
