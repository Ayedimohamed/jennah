import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BlogInfosComponent } from './blog-infos.component';

describe('BlogInfosComponent', () => {
  let component: BlogInfosComponent;
  let fixture: ComponentFixture<BlogInfosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BlogInfosComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BlogInfosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
