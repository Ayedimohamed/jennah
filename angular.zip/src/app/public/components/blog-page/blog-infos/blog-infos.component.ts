import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-infos',
  templateUrl: './blog-infos.component.html',
  styleUrls: ['./blog-infos.component.scss']
})
export class BlogInfosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
