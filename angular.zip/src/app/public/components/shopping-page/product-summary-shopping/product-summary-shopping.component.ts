import { ChangeDetectorRef, Component, Inject, OnInit } from '@angular/core';
import { IgxOverlayService } from 'igniteui-angular';
import { MainDataService } from 'src/app/shared/services/main-data.service';
import { ShopService } from 'src/app/shared/services/shop.service';
import { environment } from 'src/environments/environment';
import { QuickViewComponent } from '../../quick-view/quick-view.component';


const API_URL = environment.API_URL;

@Component({
  selector: 'app-product-summary-shopping',
  templateUrl: './product-summary-shopping.component.html',
  styleUrls: ['./product-summary-shopping.component.scss']
})

export class ProductSummaryShoppingComponent implements OnInit {

  
  public baseurl = API_URL;

  private _overlayId: string | undefined;
  public onSale: boolean = false;
  public titles : any = [];
  public i : any;
    
  /* general */
  public open = false;
  public fetched = false;

  /* initData */
  public products = [];
  public baseProducts = [];
  public categories = [];
  public subCategories = [];

  constructor(
    @Inject(IgxOverlayService) public overlayService: IgxOverlayService,  
    private ExternalRequest: ShopService,
    private chRef: ChangeDetectorRef
  ) {}

  public showOverlay() {
    if (!this._overlayId) {
      this._overlayId = this.overlayService.attach(QuickViewComponent);
    }

    this.overlayService.show(this._overlayId);
  }

  public ngOnDestroy(): void {
    if (this._overlayId) {
      this.overlayService.detach(this._overlayId);
      delete this._overlayId;
    }
  }  

  
  ngOnInit(): void {
    this.initData();
  }

  initData(){
    this.ExternalRequest.getAll().subscribe( data => {
      this.open = true;
      this.products = data.products;
      console.log("info", this.products)
      this.baseProducts = data.products;
      this.categories = data.categories;
      this.subCategories = data.subCategories;
      this.chRef.detectChanges();
      this.fetched = true;
    });
  }
  
}
