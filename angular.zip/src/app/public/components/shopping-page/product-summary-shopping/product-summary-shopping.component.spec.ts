import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductSummaryShoppingComponent } from './product-summary-shopping.component';

describe('ProductSummaryShoppingComponent', () => {
  let component: ProductSummaryShoppingComponent;
  let fixture: ComponentFixture<ProductSummaryShoppingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductSummaryShoppingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductSummaryShoppingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
