import { Component, Inject, OnInit } from '@angular/core';
import { IgxOverlayService } from 'igniteui-angular';
import { QuickViewComponent } from '../../quick-view/quick-view.component';

@Component({
  selector: 'app-product-summary',
  templateUrl: './product-summary.component.html',
  styleUrls: ['./product-summary.component.scss']
})
export class ProductSummaryComponent implements OnInit {

  private _overlayId: string | undefined;
  public onSale: boolean = false;
  public titles : any = [];
  public i : any;

  constructor(
    @Inject(IgxOverlayService) public overlayService: IgxOverlayService
  ) {}

  public showOverlay() {
    if (!this._overlayId) {
      this._overlayId = this.overlayService.attach(QuickViewComponent);
    }

    this.overlayService.show(this._overlayId);
  }

  public ngOnDestroy(): void {
    if (this._overlayId) {
      this.overlayService.detach(this._overlayId);
      delete this._overlayId;
    }
  }

  
  ngOnInit() {   

    this.titles = ['1,00 DT','2,00 DT','3,00 DT','24,00 DT','5,00 DT','6,00 DT','7,00 DT','8,00 DT','9,00 DT','10,00 DT','11,00 DT','12,00 DT']
  }

}
