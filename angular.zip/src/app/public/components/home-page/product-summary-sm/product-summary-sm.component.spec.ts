import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductSummarySmComponent } from './product-summary-sm.component';

describe('ProductSummarySmComponent', () => {
  let component: ProductSummarySmComponent;
  let fixture: ComponentFixture<ProductSummarySmComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductSummarySmComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductSummarySmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
