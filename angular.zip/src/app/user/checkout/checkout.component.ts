import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { environment } from 'src/environments/environment';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.scss']
})
export class CheckoutComponent implements OnInit {

  public error: any;
  public success: any;

  public mod = 'form1';

  // public regionsList = [];

  // public selectedFiles: FileList;
  // public currentFile: File;
  // public baseUrl = environment.IMG_URL;
  // public imageUrl = '../../../../../assets/Fr-En/image/other/download.png';

  // public dateDepart = null;
  // public afficher = false;
  // public speciality = null;
  // public sexe = null;


  // public contactForm = this.formBuilder.group({
  //   action: new FormControl('', [Validators.required]),
  //   lastName: new FormControl('', [Validators.required]),
  //   firstName: new FormControl('', [Validators.required]),
  //   nationality: new FormControl('', [Validators.required]),
  //   email: new FormControl('', [Validators.required]),
  //   phone: new FormControl('', [Validators.required]),
  //   dateNaissance: new FormControl('', [Validators.required]),
  //   adresse: new FormControl('', [Validators.required]),
  //   codePostal: new FormControl('', [Validators.required]),
  //   ville: new FormControl('', [Validators.required]),
  //   password: new FormControl('', [Validators.required]),
  //   destination: new FormControl('', [Validators.required]),
  // });

  constructor(
    private formBuilder: FormBuilder,
    private activatedroute: ActivatedRoute
  ) { }

  ngOnInit(): void {
  }

  changeMod(mod: string){
    this.mod = mod;
  }

  // initRegions() {
  //   this.externalRequest.getAllRegions('api', 'pages').subscribe((data) => {
  //       this.regionsList = data;
  //     }
  //   );
  // }

  // afficherCalendar(){
  //   this.afficher = true;
  // }

  // getDateDepart(date){
  //   this.dateDepart = date;
  //   console.log(this.dateDepart );
  // }

  // send(mod) {
  //   const formData: FormData = new FormData();
  //   formData.append('file', this.currentFile);
  //   console.log(this.speciality);

  //   const dataInfo = {
  //     speciality: this.speciality,
  //     action: this.contactForm.value.action,
  //     medConsult : this.medConsult,
  //     sexe: this.sexe,
  //     lastName: this.contactForm.value.lastName,
  //     firstName: this.contactForm.value.firstName,
  //     nationality: this.contactForm.value.nationality,
  //     email: this.contactForm.value.email,
  //     phone: this.contactForm.value.phone,
  //     dateNaissance: this.contactForm.value.dateNaissance,
  //     adresse: this.contactForm.value.adresse,
  //     codePostal: this.contactForm.value.codePostal,
  //     ville: this.contactForm.value.ville,
  //     password: this.contactForm.value.password,
  //     destination: this.contactForm.value.destination,
  //     dateDepart: this.dateDepart
  //   };
  //   console.log('dataInfo' ,dataInfo);

  //   formData.append('data', JSON.stringify(dataInfo));

  //   console.log('formData' ,formData);

  //   this.externalRequest.sendDemande(formData, 'api', 'devises').subscribe(
  //     (data) => {
  //       this.changeMod(mod);
  //     },
  //     (error) => {
  //       this.error = error.originalError.error.message;
  //     }
  //   );
  // }

}
