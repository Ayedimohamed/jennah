import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-love-list',
  templateUrl: './love-list.component.html',
  styleUrls: ['./love-list.component.scss']
})
export class LoveListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
