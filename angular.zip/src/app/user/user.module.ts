import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShoppingCartComponent } from './shopping-cart/shopping-cart.component';
import { LoveListComponent } from './love-list/love-list.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { AppRoutingModule } from '../app-routing.module';
import { SuccessComponent } from './success/success.component';


const SharedModules = [
  AppRoutingModule
];

const SharedComponents = [
  ShoppingCartComponent,
  LoveListComponent,
  CheckoutComponent,
  SuccessComponent
];


@NgModule({
  declarations: [SharedComponents],
  imports: [
    CommonModule,
    SharedModules
  ],
  exports: [
    SharedModules,
    SharedComponents
  ]
})
export class UserModule { }
