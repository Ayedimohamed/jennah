import { JsLoaderDirective } from './js-loader.directive';

describe('JsLoaderDirective', () => {
  it('should create an instance', () => {
    const directive = new JsLoaderDirective();
    expect(directive).toBeTruthy();
  });
});
