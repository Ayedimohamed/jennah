
import { environment } from '../../../environments/environment';
import { AppError } from '../errors/app-error';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { catchError, map } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { Inject, Injectable } from '@angular/core';
import { AuthService } from './auth.service';

const API_URL = environment.API_URL;


@Injectable({
  providedIn: 'root'
})
export class MainDataService {  
  
  public baseUrl = API_URL;

  protected constructor(
    protected route: string,
    protected controller: string,
    protected http: HttpClient,
    protected Auth: AuthService
  ) { }

  createHeader(){
    const  headers = new HttpHeaders()
      .set('Content-Type', 'application/x-www-form-urlencoded');

    return headers;
}

createDataHeader(){
  const  headers = new HttpHeaders();
  return headers;
}

  createBody(data){
    const body = new HttpParams()
      .set('data', JSON.stringify(data));
    return body;
  }

  createDataBody(data){
    const body = new FormData();
    body.append('data', data);
    return body;
  }

  createroute(route?){
    if (route){
      return route;
    }
    return this.route;
  }

  createcontroller(controller?){
    if (controller){
      return controller;
    }
    return this.controller;
  }

  public get(id, route?, controller?){
    return this.http.get(this.baseUrl + this.createroute(route) + '/' + this.createcontroller(controller) + '/get.json?id=' + id, {headers: this.createHeader() })
    .pipe(map(this.handleResponse), catchError(this.handleError));
  }

  public getAll(route?, controller?){
    return this.http.get(this.baseUrl + this.createroute(route) + '/' + this.createcontroller(controller) + '/getAll.json', { headers: this.createHeader() })
    .pipe(map(this.handleResponse), catchError(this.handleError));
  }

  public handleError(error: Response){
    return throwError(new AppError(error));
  }

  public handleResponse(response: Response){
    // @ts-ignore
    return response.data ;
  }

  public handleJsonResponse(response: Response){
    // @ts-ignore
    return response;
  }

}
