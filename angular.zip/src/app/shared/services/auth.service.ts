import { EventEmitter, Injectable, Output } from '@angular/core';

import { BehaviorSubject } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { JwtHelperService } from '@auth0/angular-jwt';
import { environment } from '../../../environments/environment';
import * as CryptoJS from 'crypto-js';
import { UserInterface } from '../interface/user.interface';


const API_URL = environment.API_URL;
const secretKey = environment.Sk;

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  @Output() change: EventEmitter<string> = new EventEmitter();

  private loggedIn = new BehaviorSubject<boolean>(this.isLoggedIn());
  private loggedInUser = new BehaviorSubject<any>(this.getUserInformation());

  authStatus = this.loggedIn.asObservable();
  activeUser = this.loggedInUser.asObservable();

  constructor(
    private http: HttpClient,
  ) { }


  get() {
    const token = localStorage.getItem('ST_AD_TK');
    if (token) { return this.decrypt(token); }
    return null;
  }

  login(token: any) {
    localStorage.setItem('ST_AD_TK', this.encrypt(token));
    this.changeAuthStatus(true);
    this.changeLoggedInUser();
  }

  update(token?: any) {
    if (token) {
      localStorage.setItem('ST_AD_TK', this.encrypt(token));
    }

    this.loggedInUser.next(this.getUserInformation());
  }

  logout() {
    localStorage.removeItem('ST_AD_TK');
    this.changeAuthStatus(false);
  }

  changeAuthStatus(value: boolean) {
    this.loggedIn.next(value);
  }

  changeLoggedInUser() {
    const loggedin = this.getUserInformation();

    this.loggedInUser.next(loggedin);
  }

  isLoggedIn() {
    const jwtHelper = new JwtHelperService();
    const token = localStorage.getItem('ST_AD_TK');
    if (!token) {
      return false;
    } else {
      if (!jwtHelper.isTokenExpired(this.decrypt(token))) {
        this.refreshToken();
        return true;
      }
      else {
        return false;
      }
    }

  }

  refreshToken() {
    this.http.get(API_URL + 'users/refreshToken.json', {
      headers: new HttpHeaders()
        .set('Content-Type', 'application/x-www-form-urlencoded')
        .set('Authorization', this.get())
    }).subscribe(
      data => this.handleResponse(data),
      error => console.log(error)
    );
  }

  handleResponse(data: any) {
    this.update(data.data.token);
  }

  getUserInformation() {
    const token = localStorage.getItem('ST_AD_TK');
    if (!token) { return null; }
    const jwtHelper = new JwtHelperService();
    const result = jwtHelper.decodeToken(this.decrypt(token));
    const activeUser: UserInterface[] = [
      {
        id: result.id,
        email: result.email,
        pseudo: result.pseudo,
        role: result.role,
        firstName: result.firstName,
        lastName: result.lastName,
      }
    ];
    return activeUser;
  }


  encrypt(data: any): string {
    return CryptoJS.AES.encrypt(JSON.stringify(data), secretKey.trim()).toString();
  }

  decrypt(textToDecrypt: string) {
    return JSON.parse(CryptoJS.AES.decrypt(textToDecrypt, secretKey.trim()).toString(CryptoJS.enc.Utf8));
  }

}
