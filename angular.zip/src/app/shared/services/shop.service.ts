import { catchError, map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { MainDataService } from './main-data.service';
import { Injectable } from '@angular/core';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class ShopService  extends MainDataService{
  

  constructor(http: HttpClient,Auth: AuthService) {
    super('products','', http,Auth);
  }

  public getAll(route?: any, controller?: any) {
    return this.http.get(this.baseUrl + this.createroute(route) + '/' + this.createcontroller(controller) + 'getAll.json', { headers: this.createHeader() })
    .pipe(
      map(this.handleResponse),
      catchError(this.handleError)
    )
  }

  
  public get(id, route?, controller?){
    return this.http.get(this.baseUrl + this.createroute(route) + '/' + this.createcontroller(controller) + 'get.json?id=' + id, {headers: this.createHeader() })
    .pipe(map(this.handleResponse), catchError(this.handleError));
  }
}
