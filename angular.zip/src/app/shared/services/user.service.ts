import { AuthService } from './auth.service';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MainDataService } from './main-data.service';
import { catchError, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class UserService extends MainDataService{

  constructor(http: HttpClient, Auth: AuthService) {
     super('users','', http, Auth);
   }

  
  public login(data,route?: any, controller?: any){
    return this.http.post( this.baseUrl + 'users/frontLogin.json', this.createBody(data),  { headers: this.createHeader()})
    .pipe(
      map(this.handleResponse),
      catchError(this.handleError)
    )
  }
}
