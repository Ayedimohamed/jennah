export interface UserInterface {
  id: number;
  email: string;
  pseudo: string;
  role: string;
  firstName: string;
  lastName: string;
}
