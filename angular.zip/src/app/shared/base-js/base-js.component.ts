import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-base-js',
  templateUrl: './base-js.component.html',
  styleUrls: ['./base-js.component.scss']
})
export class BaseJsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {

  }

}
