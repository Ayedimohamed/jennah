import {ErrorHandler, NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { JsLoaderDirective } from './directives/js-loader.directive';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {clickAloneDirective} from './directives/click-alone';
import { BaseJsComponent } from './base-js/base-js.component';


const SharedModules = [
  FormsModule,
  ReactiveFormsModule,
  HttpClientModule
];

const SharedComponents = [
  clickAloneDirective,
  BaseJsComponent,
  JsLoaderDirective
];


@NgModule({
  declarations: [SharedComponents],
  imports: [
    CommonModule,
    SharedModules
  ],
  exports : [
    SharedModules,
    SharedComponents
  ]
})
export class SharedModule { }
