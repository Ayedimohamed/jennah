import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forgot-pswd',
  templateUrl: './forgot-pswd.component.html',
  styleUrls: ['./forgot-pswd.component.scss']
})
export class ForgotPswdComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
