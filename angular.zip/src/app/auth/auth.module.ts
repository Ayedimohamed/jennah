import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { ForgotPswdComponent } from './forgot-pswd/forgot-pswd.component';
import { InscriptionComponent } from './inscription/inscription.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


const MySharedModules = [
  FormsModule,
  ReactiveFormsModule,
];

const MySharedComponents = [
  LoginComponent,
  ForgotPswdComponent,
  InscriptionComponent
];

@NgModule({
  declarations: [MySharedComponents],
  imports: [
    CommonModule,
    MySharedModules
  ],
  exports : [
    MySharedModules,
    MySharedComponents
  ]
})
export class AuthModule { }
