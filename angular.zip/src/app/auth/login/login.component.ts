
import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import { UserInterface } from 'src/app/shared/interface/user.interface';
import { AuthService } from 'src/app/shared/services/auth.service';
import { UserService } from 'src/app/shared/services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  public error = null;
  public activeUser: UserInterface;

  constructor(
    private ExternalRequest: UserService,
    private authService: AuthService,
  ) { }

  ngOnInit(): void {
  }




  public user = new FormGroup({
    username: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required, Validators.minLength(6)])
  });
  get username(){
    return this.user.get('username');
  }
  get password(){
    return this.user.get('password');
  }
  onSubmit(){
    this.ExternalRequest.login(this.user.value).subscribe(
      data => this.handleResponse(data),
      error => this.handleError(error)
    );    
    console.log(this.user.value)
  }
  handleResponse(data) {
    this.authService.login(data.token);
    const result = this.authService.getUserInformation();
    this.activeUser = result[0];
    window.location.href="/";
  }
  handleError(error) {
    this.error = error.originalError.error.message;
  }

}
