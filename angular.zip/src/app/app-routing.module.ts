import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './auth/login/login.component';
import { ProductDetailComponent } from './public/components/product-details-page/product-detail/product-detail.component';
import { AboutUsComponent } from './public/pages/about-us/about-us.component';
import { BlogDetailsComponent } from './public/pages/blog-details/blog-details.component';
import { BlogComponent } from './public/pages/blog/blog.component';
import { HomeComponent } from './public/pages/home/home.component';
import { PromotionComponent } from './public/pages/promotion/promotion.component';
import { ShoppingComponent } from './public/pages/shopping/shopping.component';
import { CheckoutComponent } from './user/checkout/checkout.component';
import { LoveListComponent } from './user/love-list/love-list.component';
import { ShoppingCartComponent } from './user/shopping-cart/shopping-cart.component';
import { SuccessComponent } from './user/success/success.component';

const routes: Routes = [
  {
    path: "",
    component: HomeComponent
  },
  {
    path: "home",
    component: HomeComponent
  },
  {
    path: "login",
    component: LoginComponent
  },
  {
    path: "shopping-cart",
    component: ShoppingCartComponent
  },
  {
    path: "love-list",
    component: LoveListComponent
  },
  {
    path: "product-detail/:id",
    component: ProductDetailComponent
  },
  {
    path: "checkout",
    component: CheckoutComponent
  },
  {
    path: "success",
    component: SuccessComponent
  },
  {
    path: "shopping",
    component: ShoppingComponent
  },
  {
    path: "promotion",
    component: PromotionComponent
  },
  {
    path: "blog",
    component: BlogComponent
  },
  {
    path: "blog-detail",
    component: BlogDetailsComponent
  },
  {
    path: "about-us",
    component: AboutUsComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
