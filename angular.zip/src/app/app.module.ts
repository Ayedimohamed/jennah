import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './layout/navbar/navbar.component';
import { FooterComponent } from './layout/footer/footer.component';
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { PublicModule } from './public/public.module';
import { SharedModule } from './shared/shared.module';
import { AuthModule } from './auth/auth.module';
import { UserModule } from './user/user.module';
import { IgxOverlayService } from 'igniteui-angular';
import { CommonModule } from '@angular/common';


const SharedModules = [
  BrowserModule,
  AppRoutingModule,
  PublicModule,
  SharedModule,
  AuthModule,
  UserModule,
  BrowserAnimationsModule
];

const SharedComponents = [
  AppComponent,
  NavbarComponent,
  FooterComponent,
];

@NgModule({
  declarations: [SharedComponents],
  imports: [
    CommonModule,
    SharedModules
  ],
  exports: [
    SharedModules,
    SharedComponents
  ],
  providers: [IgxOverlayService],
  bootstrap: [AppComponent]
})
export class AppModule { }
